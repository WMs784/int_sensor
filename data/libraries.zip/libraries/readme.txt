ライブラリのインストールについては次を参照してください：http://www.arduino.cc/en/Guide/Libraries
